const MATERIALS=[
 {id:'steel',name:'Acero S235/S275',factor:1,k:0.38,spring:1.0},
 {id:'inox',name:'Inox 304/316',factor:1.55,k:0.40,spring:2.0},
 {id:'alu',name:'Aluminio',factor:0.55,k:0.33,spring:1.5},
 {id:'galv',name:'Galvanizado',factor:1.05,k:0.38,spring:1.0}
];
const DIES=[
 {brand:'Compatible Bystronic',code:'V6',v:6,maxTon:90,thick:'0.5-1.0'},
 {brand:'Compatible Bystronic',code:'V8',v:8,maxTon:90,thick:'0.8-1.2'},
 {brand:'Compatible Bystronic',code:'V10',v:10,maxTon:100,thick:'1.0-1.5'},
 {brand:'Compatible Bystronic',code:'V12',v:12,maxTon:100,thick:'1.2-2.0'},
 {brand:'Compatible Bystronic',code:'V16',v:16,maxTon:120,thick:'1.5-2.5'},
 {brand:'Compatible Bystronic',code:'V20',v:20,maxTon:140,thick:'2.0-3.0'},
 {brand:'Compatible Bystronic',code:'V25',v:25,maxTon:160,thick:'2.5-4.0'},
 {brand:'Compatible Bystronic',code:'V32',v:32,maxTon:180,thick:'3.0-5.0'},
 {brand:'Compatible Bystronic',code:'V40',v:40,maxTon:200,thick:'4.0-6.0'},
 {brand:'Compatible Bystronic',code:'V50',v:50,maxTon:220,thick:'5.0-8.0'},
 {brand:'Compatible Bystronic',code:'V60',v:60,maxTon:250,thick:'6.0-10'},
 {brand:'Compatible Bystronic',code:'V80',v:80,maxTon:300,thick:'8.0-12'}
];
const PUNCHES=[
 {brand:'Compatible Bystronic',code:'P26 R0.6',angle:26,radius:0.6,type:'Agudo'},
 {brand:'Compatible Bystronic',code:'P30 R0.8',angle:30,radius:0.8,type:'Agudo'},
 {brand:'Compatible Bystronic',code:'P60 R1',angle:60,radius:1,type:'Estándar'},
 {brand:'Compatible Bystronic',code:'P85 R1',angle:85,radius:1,type:'Estándar'},
 {brand:'Compatible Bystronic',code:'P88 R1.5',angle:88,radius:1.5,type:'Estándar'},
 {brand:'Compatible Bystronic',code:'P90 R2',angle:90,radius:2,type:'Radio'},
 {brand:'Compatible Bystronic',code:'Gooseneck 86 R1',angle:86,radius:1,type:'Cuello de cisne'},
 {brand:'Compatible Bystronic',code:'Return bend R1',angle:30,radius:1,type:'Retorno'}
];
const PROBLEMS={
 marks:['Usar film protector o matriz con insertos.', 'Aumentar V si el radio y tonelaje lo permiten.', 'Revisar rebabas y suciedad en matriz.', 'Reducir presión si se está acuñando sin necesidad.'],
 angle:['Comprobar recuperación elástica del material.', 'Cerrar 1°-3° más según material.', 'Verificar V correcta y desgaste de herramientas.', 'Revisar paralelismo y compensación de mesa.'],
 crack:['Aumentar radio interior o abertura V.', 'Comprobar sentido de fibra.', 'Evitar punzón demasiado agudo.', 'Verificar calidad y dureza del material.'],
 bow:['Usar compensación/bombeo.', 'Revisar tonelaje uniforme.', 'Centrar la pieza y distribuir apoyos.', 'Comprobar longitud y estado de herramientas.'],
 collision:['Cambiar orden de pliegues.', 'Usar cuello de cisne.', 'Plegar primero pestañas interiores.', 'Simular altura de alas antes de plegar.']
};
