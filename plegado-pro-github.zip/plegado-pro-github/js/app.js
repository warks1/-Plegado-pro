const $=id=>document.getElementById(id);
function init(){
 document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>switchTab(b.dataset.tab)));
 MATERIALS.forEach(m=>$('material').add(new Option(m.name,m.id)));
 DIES.forEach((d,i)=>$('dieSelect').add(new Option(`${d.code} (${d.v} mm)`,i)));
 PUNCHES.forEach((p,i)=>$('punchSelect').add(new Option(`${p.code} - ${p.type}`,i)));
 ['material','thickness','length','angle','legA','legB','dieSelect','punchSelect'].forEach(id=>$(id).addEventListener('input',calculate));
 $('problem').addEventListener('change',renderProblem);
 $('aiBtn').addEventListener('click',localAI);
 renderLists(); renderProblem(); calculate();
 if('serviceWorker' in navigator) navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
}
function switchTab(id){document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===id));document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active',p.id===id));}
function mat(){return MATERIALS.find(m=>m.id===$('material').value)}
function recommendedV(t){let target=t<=3?t*8:t*10;return DIES.reduce((a,b)=>Math.abs(b.v-target)<Math.abs(a.v-target)?b:a,DIES[0])}
function recommendedPunch(angle){if(angle<=35)return PUNCHES[0]; if(angle<=65)return PUNCHES[2]; if(angle<=92)return PUNCHES[4]; return PUNCHES[6];}
function calculate(){
 const m=mat(),t=+$('thickness').value||0,L=+$('length').value||0,ang=+$('angle').value||90,A=+$('legA').value||0,B=+$('legB').value||0;
 const selectedDie=DIES[+$('dieSelect').value]; const die=selectedDie||recommendedV(t); const punch=PUNCHES[+$('punchSelect').value]||recommendedPunch(ang);
 if(!selectedDie){const idx=DIES.indexOf(die); if(idx>=0)$('dieSelect').value=idx;}
 const v=die.v; const tonM=(650*t*t*m.factor/v)/10; const total=tonM*(L/1000); const r=+(v*0.16).toFixed(2);
 const bendAngle=180-ang; const ba=(Math.PI/180)*bendAngle*(r+m.k*t); const setback=(r+t)*Math.tan((bendAngle*Math.PI/180)/2); const bd=(2*setback)-ba; const flat=A+B-bd;
 $('tonMeter').textContent=fmt(tonM)+' t/m'; $('tonTotal').textContent=fmt(total)+' t'; $('dieRec').textContent=`${die.code}`; $('punchRec').textContent=punch.code; $('radius').textContent=fmt(r)+' mm'; $('ba').textContent=fmt(ba)+' mm'; $('bd').textContent=fmt(bd)+' mm'; $('flat').textContent=fmt(flat)+' mm';
 const warn=[]; if(tonM>die.maxTon)warn.push(`Atención: tonelaje estimado ${fmt(tonM)} t/m supera el máximo orientativo de ${die.code} (${die.maxTon} t/m).`); if(A<t*4||B<t*4)warn.push('Pestaña corta: comprobar apoyo mínimo y riesgo de caída en matriz.'); if(m.id==='inox')warn.push('Inox: prever mayor recuperación elástica y más tonelaje.');
 $('warning').textContent=warn.join(' '); renderSequence(die,punch,t,ang);
}
function renderLists(){ $('dieList').innerHTML=DIES.map(d=>`<div class="item"><strong>${d.code} · V ${d.v} mm</strong><span>${d.brand} · Espesor ${d.thick} mm · Máx ${d.maxTon} t/m</span></div>`).join(''); $('punchList').innerHTML=PUNCHES.map(p=>`<div class="item"><strong>${p.code}</strong><span>${p.brand} · ${p.type} · Ángulo ${p.angle}° · Radio ${p.radius} mm</span></div>`).join('');}
function renderSequence(die,punch,t,ang){$('sequenceList').innerHTML=[`Montar matriz ${die.code} y punzón ${punch.code}.`,`Verificar espesor ${fmt(t)} mm, material y longitud real.`,`Hacer prueba corta y corregir recuperación hasta obtener ${fmt(ang)}° interior.`,`Plegar pestañas interiores o cortas primero si la pieza tiene varias líneas.`,`Comprobar colisiones; usar cuello de cisne si el ala vuelve hacia la herramienta.`].map(x=>`<li>${x}</li>`).join('');}
function renderProblem(){const arr=PROBLEMS[$('problem').value]||[];$('problemSolution').innerHTML='<strong>Posibles soluciones:</strong><ul>'+arr.map(x=>`<li>${x}</li>`).join('')+'</ul>';}
function localAI(){const q=$('aiQuestion').value.toLowerCase();let ans='Para una respuesta exacta necesito material, espesor, longitud, ángulo y herramienta disponible. Como regla rápida: V ≈ 8×espesor en acero fino, radio interior ≈ 0,16×V y el tonelaje sube mucho al reducir V.'; if(q.includes('inox'))ans='Para inox usa factor de tonelaje mayor, normalmente alrededor de 1,5× respecto al acero. Prevé más recuperación elástica y evita radios demasiado cerrados.'; if(q.includes('marca'))ans='Para evitar marcas usa film, insertos, matriz más abierta si es viable, limpieza de herramientas y evita exceso de presión.'; if(q.includes('colisi'))ans='Para colisiones: plegar primero interiores, después exteriores, revisar altura de alas y usar punzón cuello de cisne si la geometría lo pide.'; if(q.includes('matriz')||q.includes('v '))ans='Matriz rápida: acero 1 mm V8, 1,5 mm V12, 2 mm V16, 3 mm V24/V25, 4 mm V32, 5 mm V40, 6 mm V50/V60. Ajustar según radio, pestaña mínima y tonelaje.'; $('aiAnswer').textContent=ans;}
function fmt(n){return Number.isFinite(n)?(Math.round(n*100)/100).toString().replace('.',','):'-'}
init();
